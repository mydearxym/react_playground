var Reply = require('../../proxy/reply');
var support = require('../support/support');
var should = require('should');

describe('test/proxy/reply.test.js', function () {
});
