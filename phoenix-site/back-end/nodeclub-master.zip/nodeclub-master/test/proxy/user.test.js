var User = require('../../proxy/user');
var should = require('should');
var support = require('../support/support');

describe('test/proxy/user.test.js', function () {
});
