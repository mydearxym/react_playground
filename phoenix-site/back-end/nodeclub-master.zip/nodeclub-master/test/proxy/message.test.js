var Message = require('../../proxy/message');
var should = require('should');

describe('test/proxy/message.test.js', function () {
});
